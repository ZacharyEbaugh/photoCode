//
//  ContentView.swift
//  Shared
//
//  Created by Brandon  Spangler on 8/11/22.
//
import Vision
import SwiftUI

let imageLink = "example2"

struct ContentView: View {
    
    @State var textToUpdate = ["Update me!"]
    
    let imageText = TextRecognition(link: imageLink)
    
    
    var body: some View {
        VStack {
            Image(imageLink)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 300, height: 300, alignment: .topLeading)
            Button(action: {
//                print(textToUpdate)
                self.imageText.recognizeText()
                self.textToUpdate = self.imageText.getText()
//                print(textToUpdate)
            }) {
                Text("Recongize Text")
            }
            
            List(textToUpdate, id: \.self) { string in
              Text(string)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




