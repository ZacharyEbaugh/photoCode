//
//  Text2App.swift
//  Shared
//
//  Created by Brandon  Spangler on 8/11/22.
//

import SwiftUI

@main
struct Text2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
