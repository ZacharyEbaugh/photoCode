//
//  TextRecognition.swift
//  Text2
//
//  Created by Brandon  Spangler on 8/11/22.
//

import Foundation
import Vision
import SwiftUI

class TextRecognition {
    
    private var imageLink: String
    
    private var result: [String] = []
    
    init(link: String) {
        imageLink = link
    }
    
    func recognizeText() {
        // Get the CGImage on which to perform requests.
        guard let cgImage = UIImage(named: imageLink)?.cgImage else { return }

        // Create a new image-request handler.
        let requestHandler = VNImageRequestHandler(cgImage: cgImage)

        // Create a new request to recognize text.
        let request = VNRecognizeTextRequest(completionHandler: recognizeTextHandler);

        do {
            // Perform the text-recognition request.
            try requestHandler.perform([request])
        } catch {
            print("Unable to perform the requests: \(error).")
        }
    }

    private func recognizeTextHandler(request: VNRequest, error: Error?) {
        guard let observations =
                request.results as? [VNRecognizedTextObservation] else {
            return
        }
        let recognizedStrings = observations.compactMap { observation in
            // Return the string of the top VNRecognizedText instance.
            return observation.topCandidates(1).first?.string
        }
        
        // Process the recognized strings.
        result = recognizedStrings
    }
    
    func getText() -> [String] {
        return result
    }
    
}
